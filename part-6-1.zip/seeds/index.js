
//importojme funksionin qe na mundeson lidhjen me database
import sequelize from '../config/connectDB.js'
//importojme te gjithe seeds
import seedUsers from './user-seed.js'
import seedCategory from './category-seed.js'

import {seedPosts} from './post-seed.js'
import {seedLikes} from './like-seed.js'
import {seedComments} from './comments-seed.js'
const seedAll = async ()=>{
    //fshime te gjitha tabelat
    await sequelize.sync({force:true})
    //bejme seed users
    await seedUsers()
    console.log("users seeded");
    //bejme seed kategorite
    await seedCategory()
    console.log("category seeded");
    //bejme seed postimet
    await seedPosts()
    console.log("posts seeded");
    //bejme seed like
    await seedLikes()
    console.log("likes seeded");
    //bejme seed comments
    await seedComments()
    console.log("comments seeded");


    //pasi kemi bere seed te gjithe funksionet
    process.exit(0)
}

//egzekutojme funksionin
seedAll()