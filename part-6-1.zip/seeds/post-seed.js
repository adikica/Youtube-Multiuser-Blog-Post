//importojme skemen e postimit 
import {Post} from '../models/index.js'



//krijojme nje array me postime
const postData = [
    {
    userId: 1,
    catId: 3,
    title: "Titulli i blogut te pare ",
    description: `Ndryshe nga mendimi popullor, Lorem Ipsum nuk është tekst çfarëdo  Rrënjët i ka në një pjesë të letërsisë klasike Latine të viteve 45 BC, duke e bërë më shumë se 2000 vjet të lashtë  Richard McClintock, një profesor Latin ne Hampden-Sydney College në Virginia, kërkoi për një nga fjalët më të çuditshme të tekstit, consectetur dhe duke parë citimet e fjalës në letërsinë klasike zbuloi pa dyshim burimin  Lorem Ipsum vjen nga seksionet 1 10 32 dhe 1 10 33 të de Finibus Bonorum et Malorum (Ekstremet e të Mirës e të Keqes) nga Cicero, shkruar në vitin 45 BC  Libri është një traktat mbi teorine e etikës, shumë i famshëm gjatë Rilindjes  Rreshti i parë i Lorem Ipsum, Lorem ipsum dolor sit amet   vjen nga seksioni 1 10 32 
        Pjesa standarte e Lorem Ipsum e përdorur që në vitet 1500 riprodhohet më poshtë për të interesuarit  Seksionet 1 10 32 dhe 1 10 33 të de Finibus Bonorum et Malorum nga Cicero janë gjithashtu të riprodhuara në formën origjinale të shoqëruara nga versionet e përkthyera në anglisht të vitit 1914 nga H  Rackham 
        Është një fakt gjerësisht i njohur që lexuesi do të hutohet nga përmbajtja e një faqeje gjatë kohës që shikon dizenjimin  Arsyeja e përdorimit të Lorem Ipsum është sepse ka pak a shumë distribucion normal të gërmave, ndryshe nga përdorimi i  Përmbajtja këtu, përmbajtja këtu , që e bën të ngjajë me një gjuhë të lexueshme  Shumë aplikacione publikimi dhe editorë tani përdorin Lorem Ipsum si tektin e tyre bazë, dhe një kërkim  lorem ipsum  do të shfaqë shumë faqe interneti të pambaruara që në vend të përmbajtjes kanë pikërisht tekstin Lorem Ipsum  Shumë versione kanë evoluar gjatë viteve, disa në mënyë kazuale, disa me qëllim (humor dhe gjëra të ngjashme) `,
    image: "/images/post/nature1.jpg",
    createdAt: "2022-10-10 19:34:50",
  },
  {
    userId: 3,
    catId: 1,
    title: "Titulli i blogut te dyte ",
    description: `Ndryshe nga mendimi popullor, Lorem Ipsum nuk është tekst çfarëdo  Rrënjët i ka në një pjesë të letërsisë klasike Latine të viteve 45 BC, duke e bërë më shumë se 2000 vjet të lashtë  Richard McClintock, një profesor Latin ne Hampden-Sydney College në Virginia, kërkoi për një nga fjalët më të çuditshme të tekstit, consectetur dhe duke parë citimet e fjalës në letërsinë klasike zbuloi pa dyshim burimin  Lorem Ipsum vjen nga seksionet 1 10 32 dhe 1 10 33 të de Finibus Bonorum et Malorum (Ekstremet e të Mirës e të Keqes) nga Cicero, shkruar në vitin 45 BC  Libri është një traktat mbi teorine e etikës, shumë i famshëm gjatë Rilindjes  Rreshti i parë i Lorem Ipsum, Lorem ipsum dolor sit amet   vjen nga seksioni 1 10 32 
        Pjesa standarte e Lorem Ipsum e përdorur që në vitet 1500 riprodhohet më poshtë për të interesuarit  Seksionet 1 10 32 dhe 1 10 33 të de Finibus Bonorum et Malorum nga Cicero janë gjithashtu të riprodhuara në formën origjinale të shoqëruara nga versionet e përkthyera në anglisht të vitit 1914 nga H  Rackham 
        Është një fakt gjerësisht i njohur që lexuesi do të hutohet nga përmbajtja e një faqeje gjatë kohës që shikon dizenjimin  Arsyeja e përdorimit të Lorem Ipsum është sepse ka pak a shumë distribucion normal të gërmave, ndryshe nga përdorimi i  Përmbajtja këtu, përmbajtja këtu , që e bën të ngjajë me një gjuhë të lexueshme  Shumë aplikacione publikimi dhe editorë tani përdorin Lorem Ipsum si tektin e tyre bazë, dhe një kërkim  lorem ipsum  do të shfaqë shumë faqe interneti të pambaruara që në vend të përmbajtjes kanë pikërisht tekstin Lorem Ipsum  Shumë versione kanë evoluar gjatë viteve, disa në mënyë kazuale, disa me qëllim (humor dhe gjëra të ngjashme) `,
    image: "/images/post/nature2.jpg",
    createdAt: "2022-10-11 19:34:50",
  },
  {
    userId: 2,
    catId: 2,
    title: "Titulli i blogut te trete ",
    description: `Ndryshe nga mendimi popullor, Lorem Ipsum nuk është tekst çfarëdo  Rrënjët i ka në një pjesë të letërsisë klasike Latine të viteve 45 BC, duke e bërë më shumë se 2000 vjet të lashtë  Richard McClintock, një profesor Latin ne Hampden-Sydney College në Virginia, kërkoi për një nga fjalët më të çuditshme të tekstit, consectetur dhe duke parë citimet e fjalës në letërsinë klasike zbuloi pa dyshim burimin  Lorem Ipsum vjen nga seksionet 1 10 32 dhe 1 10 33 të de Finibus Bonorum et Malorum (Ekstremet e të Mirës e të Keqes) nga Cicero, shkruar në vitin 45 BC  Libri është një traktat mbi teorine e etikës, shumë i famshëm gjatë Rilindjes  Rreshti i parë i Lorem Ipsum, Lorem ipsum dolor sit amet   vjen nga seksioni 1 10 32 
        Pjesa standarte e Lorem Ipsum e përdorur që në vitet 1500 riprodhohet më poshtë për të interesuarit  Seksionet 1 10 32 dhe 1 10 33 të de Finibus Bonorum et Malorum nga Cicero janë gjithashtu të riprodhuara në formën origjinale të shoqëruara nga versionet e përkthyera në anglisht të vitit 1914 nga H  Rackham 
        Është një fakt gjerësisht i njohur që lexuesi do të hutohet nga përmbajtja e një faqeje gjatë kohës që shikon dizenjimin  Arsyeja e përdorimit të Lorem Ipsum është sepse ka pak a shumë distribucion normal të gërmave, ndryshe nga përdorimi i  Përmbajtja këtu, përmbajtja këtu , që e bën të ngjajë me një gjuhë të lexueshme  Shumë aplikacione publikimi dhe editorë tani përdorin Lorem Ipsum si tektin e tyre bazë, dhe një kërkim  lorem ipsum  do të shfaqë shumë faqe interneti të pambaruara që në vend të përmbajtjes kanë pikërisht tekstin Lorem Ipsum  Shumë versione kanë evoluar gjatë viteve, disa në mënyë kazuale, disa me qëllim (humor dhe gjëra të ngjashme) `,
    image: "/images/post/nature3.jpg",
    createdAt: "2022-10-12 19:34:50",
  },
]

//eksportojme funksionin seedPosts
export const seedPosts = ()=> Post.bulkCreate(postData)
