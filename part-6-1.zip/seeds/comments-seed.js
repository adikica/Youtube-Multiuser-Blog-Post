import { Comment } from "../models/index.js";

const commentData = [
  {
    text: "komenti per postimin me id 1 nga user 1",
    userId: 1,
    postId: 1,
  },
  {
    text: "komenti per postimin me id 1 nga user 2",
    userId: 2,
    postId: 1,
  },
  {
    text: "komenti per postimin me id 2 nga user 3",
    userId: 3,
    postId: 2,
  },
  {
    text: "komenti per postimin me id 2 nga user 2",
    userId: 2,
    postId: 2,
  },
  {
    text: "komenti per postimin me id 3 nga user 1",
    userId: 1,
    postId: 3,
  },
  {
    text: "komenti per postimin me id 3 nga user 2",
    userId: 2,
    postId: 3,
  },
  {
    text: "komenti per postimin me id 3 nga user 3",
    userId: 3,
    postId: 3,
  },

];

export const seedComments = () => Comment.bulkCreate(commentData);
