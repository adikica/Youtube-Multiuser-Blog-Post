import express from 'express'
import { EmptyResultError } from 'sequelize'
const router = express.Router()


//admin Routes
router.get('/', function(req,res){
res.send("babaxhani routes")
})
//exportojme router
export default router