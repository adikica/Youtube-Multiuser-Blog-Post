import express from 'express'
const router = express.Router()

//importojme Like Schema nga /models/index.js
import { Like } from '../../models/index.js'




//importojme middleware
import {returnUserId} from '../../middlewares/jwt.js'

// http://localhost:5000/api/like
//router.post
router.post('/',returnUserId, async (req,res)=>{

    try {
        //ruajme new like ne database

        const like = {
            userId:req.userId,
            postId:1,
            state:true
        }

        const newLike = await Like.create(like)
        return res.send(newLike)
        
    } catch (err) {
        console.log(err);
        return res.status(500).send(err)
    }
})


export default router