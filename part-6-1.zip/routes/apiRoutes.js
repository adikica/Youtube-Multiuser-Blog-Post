import express from 'express'
const router = express.Router()


//importojme routes
import authRoutes from './user/auth.js'
import categoryRoutes from './category/catRoutes.js'
import postRoutes from './post/postRoutes.js'
import likeRoutes from './post/likeRoutes.js'
import commentRoutes from './post/commentRoutes.js'
//API route http://localhost:5000/api
router.get('/',(req,res)=>{
res.send("/api")
})


//auth routes http://localhost:5000/api/auth
router.use('/auth',authRoutes )

//Category routes http://localhost:5000/api/category
router.use('/category',categoryRoutes )


//Post routes http://localhost:5000/api/post
router.use('/post',postRoutes )


//Like routes http://localhost:5000/api/like
router.use('/like',likeRoutes )


//Comment routes http://localhost:5000/api/comment
router.use('/comment',commentRoutes )


//exportojme router
export default router