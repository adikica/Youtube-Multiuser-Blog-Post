
//importojme funksionin qe na mundeson lidhjen me database
import sequelize from '../config/connectDB.js'
//importojme te gjithe seeds
import seedUsers from './user-seed.js'
import seedCategory from './category-seed.js'


const seedAll = async ()=>{
    //fshime te gjitha tabelat
    await sequelize.sync({force:true})
    //bejme seed users
    await seedUsers()
    console.log("users seeded");
    //bejme seed kategorite
    await seedCategory()
    console.log("category seeded");
    //bejme seed postimet

    //bejme seed like


    //bejme seed comments



    //pasi kemi bere seed te gjithe funksionet
    process.exit(0)
}

//egzekutojme funksionin
seedAll()