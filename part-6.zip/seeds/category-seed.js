import {Category} from '../models/index.js'


const categoryData = [
    {
        catName:"Sport",
        catDescription:"gjithcka rreth sportit",
        catImage:"/images/category/sport.jpg",
        bgColor: "#32a84c"
    },
    {
        catName:"Shendet",
        catDescription:"gjithcka rreth shendetit",
        catImage:"/images/category/shendet.jpg",
        bgColor: "#b59b62"
    },
    {
        catName:"Politike",
        catDescription:"lajmet e fundit te politikes ",
        catImage:"/images/category/politike.jpeg",
        bgColor: "#9520c7"
    },
   

]

const seedCategory = ()=> Category.bulkCreate(categoryData)

//nese perdorim export default nuk kemi cfare te nxjrrim nga objekti
export default  seedCategory