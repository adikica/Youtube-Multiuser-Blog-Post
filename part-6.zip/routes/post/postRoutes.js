import express from 'express'
const router = express.Router()


//importojme middleware
import {returnUserId} from '../../middlewares/jwt.js'

//importojme multer storage for image
import {featuredImage} from '../../middlewares/multer.js'

//importojme funksionet nga controllers
import {newPost,allPosts,singlePost,updatePost,deletePost} from '../../controllers/post/postController.js'

//Create new post Route
// http://localhost:5000/api/post/new
router.post('/new',returnUserId,featuredImage,newPost)

//shfaq te gjithe postimet Route
// http://localhost:5000/api/post/
router.get('/',allPosts)

//shfaq vetem nje postim
// http://localhost:5000/api/post/5
router.get('/:id',singlePost)

//perditesojme vetem nje postim
// http://localhost:5000/api/post/update/:id
router.put('/update/:id',returnUserId,updatePost)

//perditesojme vetem nje postim
// http://localhost:5000/api/post/update/:id
router.delete('/delete/:id',returnUserId,deletePost)



//exportojme router
export default router