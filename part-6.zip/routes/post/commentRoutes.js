import express from 'express'
const router = express.Router()

//importojme {newComment} nga controllers
import {newComment} from '../../controllers/post/commentController.js'

//importojme middleware
import {returnUserId} from '../../middlewares/jwt.js'

//route per te krijuar koment te ri
router.post('/',returnUserId,newComment)



export default router