//faili yne startues
//importojme modulet
import path from 'path'
import { fileURLToPath } from 'url';

import express from 'express';

//importojem database connect function
import sequelize from './config/connectDB.js';
//testojme lidhjen me database dhe sinkronizojme tabelat e database
try {
    //sync() sinkronizon models schema me database alter:true,force:false,force:true
    await sequelize.sync()
    await sequelize.authenticate()
    console.log("Database u lidh me sukses ... ");
} catch (err) {
    console.log(err);
    process.exit(1)   
}

//importojme apiRoute
import apiRoute from './routes/apiRoutes.js'
//importojme admin routes
import adminRoutes from './routes/adminRoutes/index.js'



//inicializojme backend app
const app = express()


//MIDDLEWARES
//deklarojme folderin publik ku do te ruajme fotot
//__filename location of the actual file 
const __filename = fileURLToPath(import.meta.url)
//__dirname location of the attual root directory
const __dirname = path.dirname(__filename)
//i themi espress qe te perdore " public directory si statik direktori"
app.use(express.static(path.join(__dirname,'public')))
//expres.json() na mundeson te pranojme data ne formatin json ne req.body
app.use(express.json())
//express.urlencoded na mundewson te pranojme data files shembull .jpg,png ...
app.use(express.urlencoded({extended:true}))
//ROUTES
//Home route  http://localhost:5000/
app.get('/',(req,res)=>{
    res.send("serveri eshte startuar ne porten 5000")
})

//Admin Routes
app.use('/babaxhani',adminRoutes)
//API route http://localhost:5000/api
app.use('/api',apiRoute)

//porta e backend app
app.listen(5000)
