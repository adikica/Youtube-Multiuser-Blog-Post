import { Sequelize } from "sequelize";

import dotenv from "dotenv"
dotenv.config()


//krijojme funksionin qe na mundeson lidhjen me database
const sequelize = new Sequelize(
    process.env.DBNAME,
    process.env.DBUSER,
    process.env.DBPASS,
    {
      host:"localhost",
      dialect:"mysql"  
    }
    )

    //eksportojme funksionin sequelize per ta importuar ne index root file 
    //dhe ne cdo  model schema qe do krijojme
export default sequelize