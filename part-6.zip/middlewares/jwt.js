import jwt from 'jsonwebtoken'

//krijojme funksionin per te gjeneruar token
 export const generateToken = (id,firstName,lastName,email)=>{
    return jwt.sign(
        {id,firstName,lastName,email},
        process.env.JWTSECRET,{expiresIn:"1d"}
        )
}


//krijojme funksionin per te cdekoduar token
export const returnUserId = (req,res,next)=>{
    //token  presim qe ta marrim nga req.headers    .cookie ose .authorization
    try {
        //marrim cookie nga req.headers.cookie
        const cookies = req.headers.cookie ||req.headers.authorization
        //sigurohemi qe kemi nje cookie
        if(cookies){
            let token = cookies
            .split(";")
            .find( (rrjesht)=> rrjesht.trim().startsWith("jwt="))
            .split("=")[1];
            //nese kemi nje toke vazhdojme
            if(token){
                jwt.verify(token,process.env.JWTSECRET,(err,decoded)=>{
                    if(err) return res.status(401).send("unauthorized")
                    //nese nuk kemi nje error kemi nje token te cdekoduar
                req.userId = decoded.id
                next()
                })
            }
        }    
    } catch (err) {
        return res.status(500).send(err)
    }

}



//krijojme funksionin per te lejuar vetem admin akses ne x route 
export const adminRole = (req,res,next)=>{
    //token  presim qe ta marrim nga req.headers    .cookie ose .authorization
    try {
        //marrim cookie nga req.headers.cookie
        const cookies = req.headers.cookie ||req.headers.authorization
        //sigurohemi qe kemi nje cookie
        if(cookies){
            let token = cookies
            .split(";")
            .find( (rrjesht)=> rrjesht.trim().startsWith("jwt="))
            .split("=")[1];
            //nese kemi nje toke vazhdojme
            if(token){
                jwt.verify(token,process.env.JWTSECRET,(err,decoded)=>{
                    if(err) return res.status(401).send("unauthorized")
                    //nese nuk kemi nje error kemi nje token te cdekoduar
                 if(decoded.role !== "admin"){
                    return res.status(401).send("unauthorized")
                 } else {
                    next()
                 }
                 
                })
            }
        }    
    } catch (err) {
        return res.status(500).send(err)
    }

}



