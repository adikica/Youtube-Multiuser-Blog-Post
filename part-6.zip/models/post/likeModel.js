//importojme DataTypes nga moduli Sequelize
import { DataTypes } from "sequelize";


//importojme funksionin sequelize nga /config...
import sequelize from "../../config/connectDB.js";
export const Like = sequelize.define('likes',{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    // like:{
    //     type:DataTypes.INTEGER,
    //      // +1 

    // },
    // dislike:{
    //     type:DataTypes.INTEGER,
    //     // + 1 dhe  like -1

    // },
    state:{
        type:DataTypes.BOOLEAN,
        allowNull:false,
        defaultValue:true

    }

    // mungojne userId dhe postId por do i krijojme ato duke perdorur "associations"
}
)