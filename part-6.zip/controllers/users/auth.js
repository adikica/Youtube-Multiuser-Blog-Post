//importojme modulet
import bcrypt from 'bcryptjs'

//importojme user schema
import {User} from '../../models/index.js'

//importojme funksionin per te gjeneruar token
import {generateToken} from '../../middlewares/jwt.js'
//funksioni qe regjistrojme nje perdorues te ri
export const register = async  (req,res)=>{
    //ketu presim te dhenat qe na vijne nga user inputs
    //te dhenat i presim ne req.body
    //kontrollojme nese te dhenat plotesojne x kushte
    if(req.body.password.length < 6) return res.send("passwordi nuk i ploteson kushtet")

   try {
    //kontrollojme nese emaili qe na vjen nga req.body nuk egziston ne database
    const checkEmail = await User.findOne({where:{email:req.body.email}})
    //nese checkEmail na kthen true
    if(checkEmail) return res.status(409).send("ky email egziston")
    //enkryptojme passwordin qe na vjen nga req.body
    const encryptedPass = bcrypt.hashSync(req.body.password,10)
    //ruajme perdoruesin ne database
    const user = {
        email:req.body.email,
        firstName:req.body.firstName,
        lastName:req.body.lastName,
       //password:bcrypt.hashSync(req.body.password,10)
        password:encryptedPass
    }
    const newUser = await User.create(user)
    //kthejme dicka ne frontend
    //mos kthe ne frontend asnjehere password
    delete newUser.dataValues.password
    console.log(req.body,"console.log req.body");
    return  res.status(201).send(newUser)
   } catch (err) {
    console.log(err);
    return res.status(500).send(err)
   }
}

//funksioni qe identifikojme nje perdorues
export const login = async (req,res)=>{
    try {
    //kontrollojme nese emaili qe na vjen nga req.body nuk egziston ne database
    const checkEmail = await User.findOne({where:{email:req.body.email}})
    //nese checkEmail na kthen true
    if(!checkEmail) return res.status(409).send("ky email nuk egziston")
    //kontrollojme nese req.body.password === checkEmail.password
    //console.log(req.body.password,checkEmail.password);
    const checkPass = bcrypt.compareSync(req.body.password,checkEmail.password)
    //nese paswordi nuk eshte 101% i sakte kthejme ne fontend 
    if(!checkPass) return res.status(500).json({mesazhi:"kredinciale te gabuara"})
    //nese gjithcka ka shkuar mire gjenerojme token dhe e kthejem ate ne frontend
        const {id,firstName,lastName,email} = checkEmail
    const token = generateToken(id,firstName,lastName,email)
        //kthejme token ne browser si cookie
     return res.status(200).cookie("jwt",token,{httpOnly:true,maxAge:60*60*24*30}).json({mesazhi:"identifikimi ishte i suksesshem"})
    } catch (err) {
        console.log(err);
        return res.status(500).send(err)
        
    }
}


//funksioni logout
export const logout = async (req,res)=>{
    //thejshte kthejme ne browser nje cookie bosh me vlefshmeri 0ms
    return res.cookie("jwt","" ,{httpOnly:true,maxAge:0}).json({mesazhi:"ju u shkeputet nga webi me sukses"})
}