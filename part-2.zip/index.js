//faili yne startues
//importojme modulet
import express from 'express';


//importojem database connect function
import sequelize from './config/connectDB.js';
//testojme lidhjen me database dhe sinkronizojme tabelat e database
try {
    //sync() sinkronizon models schema me database alter:true,force:false,force:true
    await sequelize.sync()
    await sequelize.authenticate()
    console.log("Database u lidh me sukses ... ");
} catch (err) {
    console.log(err);
    process.exit(1)   
}

//importojme apiRoute
import apiRoute from './routes/apiRoutes.js'



//inicializojme backend app
const app = express()


//MIDDLEWARES
//expres.json() na mundeson te pranojme data ne formatin json ne req.body
app.use(express.json())

//ROUTES
//Home route  http://localhost:5000/
app.get('/',(req,res)=>{
    res.send("serveri eshte startuar ne porten 5000")
})
//API route http://localhost:5000/api
app.use('/api',apiRoute)

//porta e backend app
app.listen(5000)
