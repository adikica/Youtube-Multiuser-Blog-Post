//importojme te gjitha models schema

import { User } from "./user/userModel.js";














//i eskportojme ato

export {
    User
}