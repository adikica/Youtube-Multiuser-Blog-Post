//importojme  DataTypes nga moduli Sequelize
import {DataTypes, INTEGER } from "sequelize";

//importojme funksionin sequelize nga /config/connectDB
import sequelize from '../../config/connectDB.js'

//krijojme skemen e userit
// table name
// atributet e perdoruesit
// opsione shtese te tabeles  ... ne kete rast tabeles user vetem
export const User = sequelize.define(
    "user",
    {
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    firstName:{
        type:DataTypes.STRING,
        allowNull:false // nuk lejojem te ruhet nje perdorues pa asnje germe 
    },
    lastName:{
        type:DataTypes.STRING,
        allowNull:false // nuk lejojem te ruhet nje perdorues pa asnje germe 
    },
    email:{
        type:DataTypes.STRING,
        unique:true,
        allowNull:false // nuk lejojem te ruhet nje perdorues pa asnje germe 
    },
    password:{
        type:DataTypes.STRING,
        allowNull:false // nuk lejojem te ruhet nje perdorues pa asnje germe 
    }
},

{
       // freezeTableName:true,
      indexes:[{fields: ['email']}]
}
)