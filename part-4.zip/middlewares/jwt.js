import jwt from 'jsonwebtoken'

//krijojme funksionin per te gjeneruar token
 export const generateToken = (id,firstName,lastName,email)=>{
    return jwt.sign(
        {id,firstName,lastName,email},
        process.env.JWTSECRET,{expiresIn:"1d"}
        )
}


//krijojme funksionin per te cdekoduar token