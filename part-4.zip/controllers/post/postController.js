import { Post } from '../../models/index.js'

//funskioni per te krijuar nje postim te ri dhe e ruajme ne database
export const newPost = async (req, res) => {
    //presim te dhenat e postimit ne req.body
    const imgPath = req.file.destination.replace("./public", "")
    const imageString = imgPath + req.file.filename
    try {
        const post = {
            title: req.body.title,
            description: req.body.description,
            image: imageString,
            catId: 1,
            userId: 1,
        }
        const newPost = await Post.create(post)
        console.log(req.body, req.file);
        return res.send(req.body)

    } catch (err) {
        return res.status(500).send(err)

    }

}

//funskioni per te kthyer ne frontend te gjitha postimet

export const allPosts = async (req, res) => {
    try {
        const posts = await Post.findAll()
        return res.status(200).send(posts)
    } catch (err) {
        return res.status(500).send(err)

    }
}


//funskioni per te kthyer ne frontend te gjitha postimet
export const singlePost = async (req, res) => {
    console.log(req.params);
    try {
        const post = await Post.findByPk(req.params.id)
        //const post = await Post.findOne({where:{id:req.params.id}})
        return res.status(200).send(post)
    } catch (err) {
        return res.status(500).send(err)
    }
}

//funskioni per te perditesuar nje postim
export const updatePost = async (req, res) => {
    //na duhet userId qe eshte indentifikuar ne frontend
    console.log(req.params.id);
    console.log(req.body.title);

    try {
        // const post = Post.findByPk(1) 
        // if(req.userId !== post.userId){
        //         // nese userid nuk eshte i njejte me userId qe na kthen post  
        //         //nuk lekjojme ndryshimet
        //         return res.send("perditesimi deshtoi")
        // }  


        const updatedPost = await Post.update(
            { title: req.body.title },
            { where: { id: req.params.id } }
        )

        return res.status(201).send(updatedPost)
    } catch (err) {
        return res.status(500).send(err)
    }
}

//funskioni per te fshire nje postim

export const deletePost = async (req, res) => {
    //pasi kemi id e blogut

    try {
        //disa kushte parase te fshiume blogun

        //shikojme nese blogu me X id egziston...

        /*nese egziston verifikojme nese perdoruesi qe ka derguar 
        kerkesen per tu fshi blogu eshte ai autori i atij blogu
        */

        const deleteBlog = await Post.destroy({ where: { id: req.params.id } })
        return res.send("postimi u fshi")

    } catch (err) {
        return res.send(err)

    }

}