//importojme DataTypes nga moduli Sequelize
import { DataTypes } from "sequelize";


//importojme funksionin sequelize nga /config...
import sequelize from "../../config/connectDB.js";


export const Post = sequelize.define('posts',{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    title:{
        type:DataTypes.STRING,

    },
    description:{
        type:DataTypes.TEXT,
    },
    image:{
        type:DataTypes.STRING,     
    },


},{
    freezeTableName:true
})
