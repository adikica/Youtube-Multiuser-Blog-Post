//importojme te gjitha models schema

import { User } from "./user/userModel.js";
import {Category} from './category/catModel.js'
import { Post } from "./post/postModel.js";
import { Like } from "./post/likeModel.js";
import { Comment } from "./post/commentModel.js";

//lidhjen mes skemave do ta bejme pikerisht ne kte file
/*
shembull 1: postimi i perket nje perdoruesi 
shembull 2 : perdoruesi ka me shume se 1 blog
shembull 3 : komenti i perket nje blogu dhe nje perdoruesi
*/

//Post
//postimi i perket nje perdoruesi 
Post.belongsTo(User,{foreignKey:"userId" ,as:"user"})
Post.hasMany(Comment,{as:'postComments',onDelete:"cascade"})
Post.hasMany(Like,{as:'postLikes',onDelete:"cascade"})

//User
User.hasMany(Post,{as:"userPosts",onDelete:"cascade"})
User.hasMany(Comment,{as:"userComments",onDelete:"cascade"})
User.hasMany(Like,{as:"userLikes",onDelete:"cascade"})

//Category
Category.hasMany(Post,{foreignKey:"catId", as:"categoryBlogs"})



//Likes
Like.belongsTo(User)
Like.belongsTo(Post)
//Comments
Comment.belongsTo(User)   //do na krijohen  userId {foreignKey:"userId"}
Comment.belongsTo(Post)//do na krijohen  postId {foreignKey:"postId"}






//i eskportojme ato
export {
    User,
    Category,
    Post,
    Like,
    Comment
}