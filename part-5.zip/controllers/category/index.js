//imnportojme cat schema nga /models/index.js

import {Category} from '../../models/index.js'

export const newCategory = async (req,res)=>{
        try {
            const imgPath = req.file.destination.replace("./public","")
            const catimageString =  imgPath + req.file.filename
            // catimagestring = /images/category/2022/dhjetor1672410270554.jpg
            const category = {
            catName:req.body.catName,
            catDescription:req.body.catDescription,
            catImage:catimageString
                }
            const newCat = await Category.create(category)
        return res.status(201).send("kategoria u krijua me sukses")
                //vazhdoni vete me pjesen e mbetur
        } catch (err) {
            console.log(err);
            return res.status(500).send(err)
            
        }

}