
//marrim comment schema nga /models/index.js
import {Comment} from '../../models/index.js'

//funksioni per te ruajtur nje koment ne database

export const newComment = async (req,res)=>{
console.log(req.headers);
    try {
        // na duhen 
        // 1 id e perdoruesit do e marrim nga credintials qe dergohen ne req.headers
        // 2 id e postimit do e pasojme nga frontend , 
        // ose ne req.body ose req.params ose req.query
        //3 na duhet dhe teksti qe perdoruesi ka shkruar dhe do e marrim nga req.body
        
        //pasi i kemi te gjitha kto vlera bejme disa kontrolle nese cfare kemi permbush kushtet per te vazhduar
        const comment = {
            userId:2,
            postId:1,
            text:"alamet postimi nga perdoruesi me id 2 per postimin me id 1"
        }
        //pasi kemi gjithcka na duhet ruajme komentin ne database
        const komenti = await Comment.create(comment)

        return res.status(201).send(komenti)

    } catch (err) {
        return res.status(500).send(err)
        
    }
}