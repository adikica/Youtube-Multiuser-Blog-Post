import express from 'express'
const router = express.Router()

//importojme {newComment} nga controllers
import {newComment} from '../../controllers/post/commentController.js'


//route per te krijuar koment te ri
router.post('/',newComment)



export default router