import express from 'express'
const router = express.Router()

//importojme Like Schema nga /models/index.js
import { Like } from '../../models/index.js'

// http://localhost:5000/api/like
//router.post
router.post('/',async (req,res)=>{

    try {
        //ruajme new like ne database

        const like = {
            userId:2,
            postId:1,
            state:true
        }

        const newLike = await Like.create(like)
        return res.send(newLike)
        
    } catch (err) {
        console.log(err);
        return res.status(500).send(err)
    }
})


export default router