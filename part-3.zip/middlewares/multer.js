import multer from 'multer'
import path from 'path'
import fs from 'fs'


//krijojme 12 muajt e vitit
const monthNames = ["janar","shkurt","mars","prill","maj","qershor",
"korrik","gusht","shtator","tetor","nendor","dhjetor",]

const d = new Date()

//gjejme muajn aktual dhe e pasojme indexin e monthNames
const month = monthNames[d.getMonth()]   //dhjetor  >> // janar
const year = new Date().getFullYear()   // 2022  >> // 2023

//multer storage
const catStorage = multer.diskStorage({
    destination:(req,file,cb)=>{
        console.log(file);
        //krojojme path ku do ruajme fotot e kategorise
        const imgPath = `./public/images/category/${year}/${month}`
        //perdorim fs per te krijuar ate direktori nese nuk egziston
        fs.mkdirSync(imgPath,{recursive:true})
        //nese kemi error null dhe nese gjithcka ka shkuar mire kthjme imgPath
        cb(null,imgPath)
    },
    filename:(req,file,cb)=>{
        cb(null,Date.now() + path.extname(file.originalname))
    }
})


//krojojme multer middleware
export const catImage = multer({
    storage:catStorage,
    fileFilter:(req,file,cb)=>{
        if(file.mimetype == "image/png" || file.mimetype == "image/jpg" 
        || file.mimetype == "image/jpeg"){
            cb(null,true)
        }else{
            cb(null,false)
            return cb(new Error("vetem formate .png .jpg dhe .jpeg jane te lejuara"))
        }
    }
    //limits:fileSize:'1000000' 1mb,
 }).single('catImage')


