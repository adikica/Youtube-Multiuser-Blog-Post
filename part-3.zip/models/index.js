//importojme te gjitha models schema

import { User } from "./user/userModel.js";
import {Category} from './category/catModel.js'


//lidhjen mes skemave do ta bejme pikerisht ne kte file
/*
shembull 1: postimi i perket nje perdoruesi 
shembull 2 : perdoruesi ka me shume se 1 blog
shembull 3 : komenti i perket nje blogu dhe nje perdoruesi
*/










//i eskportojme ato

export {
    User,
    Category
}