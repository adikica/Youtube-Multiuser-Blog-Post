//imnportojme cat schema nga /models/index.js

import {Category} from '../../models/index.js'

export const newCategory = async (req,res)=>{
    console.log(req.file,req.body);
    const catimageString = "????"
    // catimagestring = /images/category/2022/dhjetor/1672410270554.jpg
    const category = {
    catName:req.body.catName,
    catDescription:req.body.catDescription,
    catImage:catimageString
        }
        const newCat = await Category.create(category)

        //vazhdoni vete me pjesen e mbetur

}