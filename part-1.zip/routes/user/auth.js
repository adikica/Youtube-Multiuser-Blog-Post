import express from 'express'
const router = express.Router()

//importojme funksionet nga controllers
import {register} from '../../controllers/users/auth.js'



//API route http://localhost:5000/api/auth
router.get('/',(req,res)=>{
res.send("/auth route")
})


//Register Route
// http://localhost:5000/api/auth/register
router.post('/register',register)

//Login Route





//exportojme router
export default router