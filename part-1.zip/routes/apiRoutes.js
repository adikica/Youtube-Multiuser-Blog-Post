import express from 'express'
const router = express.Router()


//importojme routes
import authRoutes from './user/auth.js'

//API route http://localhost:5000/api
router.get('/',(req,res)=>{
res.send("/api")
})


//
router.use('/auth',authRoutes )



//exportojme router
export default router