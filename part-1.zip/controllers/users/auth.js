export const register = (req,res)=>{
    //ketu presim te dhenat qe na vijne nga user inputs
    //te dhenat i presim ne req.body
    console.log(req.body,"console.log req.body");
    res.send("register post request route from controllers")
}